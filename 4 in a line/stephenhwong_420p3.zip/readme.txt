Compile:
1. javac FourLine.java
	Keep FourLine.java and Board.java within the same directory.
	
2. java FourLine