Compile:
1. javac Puzzle.java
	Keep Square.java and Node.java within the same directory.
	
2. java Puzzle

3. Read the small directions the terminal displays and generate either a. random puzzles or b. puzzles of own choice.