﻿1. javac NQueen.java with Board.java and Queen.java in the same directory
2. java NQueen 
3. Can modify the variables at the top of NQueen for further testing